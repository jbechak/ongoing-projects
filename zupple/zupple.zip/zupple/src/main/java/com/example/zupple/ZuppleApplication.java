package com.example.zupple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZuppleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZuppleApplication.class, args);
	}

}
